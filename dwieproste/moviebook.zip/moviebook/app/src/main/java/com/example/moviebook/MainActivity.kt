package com.example.moviebook

import com.example.moviebook.Item
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson

class MainActivity : AppCompatActivity() {

    private val itemList = mutableListOf<Item>()
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val titleEditText: EditText = findViewById(R.id.editTitle)
        val genreEditText: EditText = findViewById(R.id.editGenre)
        val descriptionEditText: EditText = findViewById(R.id.editDescription)
        val ratingSeekBar: SeekBar = findViewById(R.id.seekBarRating)
        val radioGroup: RadioGroup = findViewById(R.id.radioGroupType)
        val buttonAdd: Button = findViewById(R.id.buttonAdd)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = ItemAdapter(itemList) { item ->
            showItemDetails(item)
        }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        buttonAdd.setOnClickListener {
            val title = titleEditText.text.toString()
            val genre = genreEditText.text.toString()
            val description = descriptionEditText.text.toString()
            val rating = ratingSeekBar.progress
            val type = if (radioGroup.checkedRadioButtonId == R.id.radioButtonMovie) "Movie" else "Book"

            val newItem = Item(title, genre, description, rating, type)
            itemList.add(newItem)
            adapter.notifyItemInserted(itemList.size - 1)

            saveData()
        }
    }

    private fun saveData() {
        val gson = Gson()
        val json = gson.toJson(itemList)
        val sharedPreferences = getSharedPreferences("MovieBookTracker", MODE_PRIVATE)
        sharedPreferences.edit().putString("itemList", json).apply()
    }

    private fun loadData() {
        val sharedPreferences = getSharedPreferences("MovieBookTracker", MODE_PRIVATE)
        val json = sharedPreferences.getString("itemList", "[]")
        val gson = Gson()
        val loadedList = gson.fromJson(json, Array<Item>::class.java).toList()
        itemList.clear()
        itemList.addAll(loadedList)
        adapter.notifyDataSetChanged()
    }

    private fun showItemDetails(item: Item) {
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setMessage("Gatunek: ${item.genre}\nOpis: ${item.description}\nOcena: ${item.rating}")
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }
}

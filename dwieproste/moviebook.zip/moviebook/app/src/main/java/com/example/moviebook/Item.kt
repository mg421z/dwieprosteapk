package com.example.moviebook

data class Item(
    val title: String,
    val genre: String,
    val description: String,
    val rating: Int,
    val type: String,
    val isCompleted: Boolean = false
)

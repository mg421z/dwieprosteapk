package com.example.fitness

data class Trening(
    val typ: String,
    val dystans: Double,
    val czas: Double,
    val kalorie: Int,
    val intensywnosc: Int
)


package com.example.fitness

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson

class MainActivity : AppCompatActivity() {

    private val treningi = mutableListOf<Trening>()
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val typRadioGroup: RadioGroup = findViewById(R.id.radioGroupTyp)
        val dystansInput: EditText = findViewById(R.id.editTextDystans)
        val czasInput: EditText = findViewById(R.id.editTextCzas)
        val kalorieInput: EditText = findViewById(R.id.editTextKalorie)
        val intensywnoscSeekBar: SeekBar = findViewById(R.id.seekBarIntensywnosc)
        val dodajButton: Button = findViewById(R.id.buttonDodaj)
        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewTreningi)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = TreningAdapter(treningi)

        dodajButton.setOnClickListener {
            val typ = when (typRadioGroup.checkedRadioButtonId) {
                R.id.radioSpacer -> "Spacer"
                R.id.radioBieg -> "Bieg"
                R.id.radioSilowy -> "Trening siłowy"
                else -> "Inne"
            }
            val nowyTrening = Trening(
                typ,
                dystansInput.text.toString().toDoubleOrNull() ?: 0.0,
                czasInput.text.toString().toDoubleOrNull() ?: 0.0,
                kalorieInput.text.toString().toIntOrNull() ?: 0,
                intensywnoscSeekBar.progress
            )
            treningi.add(nowyTrening)
            recyclerView.adapter?.notifyDataSetChanged()
            zapiszDane()
            czyscFormularz(dystansInput, czasInput, kalorieInput)
        }

        wczytajDane()
    }

    private fun zapiszDane() {
        val json = gson.toJson(treningi)
        getSharedPreferences("fitness", MODE_PRIVATE).edit().putString("treningi", json).apply()
    }

    private fun wczytajDane() {
        val json = getSharedPreferences("fitness", MODE_PRIVATE).getString("treningi", null)
        if (json != null) {
            val type = object : com.google.gson.reflect.TypeToken<List<Trening>>() {}.type
            treningi.addAll(gson.fromJson(json, type))
            findViewById<RecyclerView>(R.id.recyclerViewTreningi).adapter?.notifyDataSetChanged()
        }
    }

    private fun czyscFormularz(vararg fields: EditText) {
        fields.forEach { it.text.clear() }
    }
}

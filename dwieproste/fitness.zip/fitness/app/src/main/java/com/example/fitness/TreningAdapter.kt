package com.example.fitness

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TreningAdapter(private val treningi: List<Trening>) : RecyclerView.Adapter<TreningAdapter.TreningViewHolder>() {

    class TreningViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val typTextView: TextView = itemView.findViewById(R.id.textTyp)
        val dystansTextView: TextView = itemView.findViewById(R.id.textDystans)
        val czasTextView: TextView = itemView.findViewById(R.id.textCzas)
        val kalorieTextView: TextView = itemView.findViewById(R.id.textKalorie)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        TreningViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_trening, parent, false))

    override fun onBindViewHolder(holder: TreningViewHolder, position: Int) {
        with(treningi[position]) {
            holder.typTextView.text = typ
            holder.dystansTextView.text = "Dystans: $dystans km"
            holder.czasTextView.text = "Czas: $czas min"
            holder.kalorieTextView.text = "Kalorie: $kalorie"
        }
    }

    override fun getItemCount() = treningi.size
}
